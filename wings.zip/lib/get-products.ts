import woo from "./woocommerce";
import type { Category } from "./products";
export async function getProducts() {
  const response = await woo.get("products", {
    per_page: 20,
    status: "publish",
  });

  return response.data.map((item: any) => ({
    id: item.id,

    name: item.name,

    english: item.slug,

    price: Number(item.price),

    image: item.images?.[0]?.src || "/images/product-placeholder.png",

    description: item.description,

    category: (item.categories?.[0]?.slug || "all") as Category,

    label: item.tags?.[0]?.name || undefined,
  }));
}
